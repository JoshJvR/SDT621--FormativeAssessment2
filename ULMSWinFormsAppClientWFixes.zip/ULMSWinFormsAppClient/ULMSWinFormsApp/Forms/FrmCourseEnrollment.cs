﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmCourseEnrollment : Form
    {
        public FrmCourseEnrollment()
        {
            InitializeComponent();
        }

        // Intentional weak business-rule validation for testing purposes (FIxed)
        private List<Enrollment> enrollments = new List<Enrollment>();

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            string studentId = txtEnrollStudentId.Text.Trim();
            string studentName = txtEnrollStudentName.Text.Trim();
            string courseName = cmbCourse.Text;
            string semester = cmbSemester.Text;

            
            if (string.IsNullOrEmpty(studentId) || string.IsNullOrEmpty(studentName) ||
                string.IsNullOrEmpty(courseName) || string.IsNullOrEmpty(semester))
            {
                MessageBox.Show("All fields are required.", "Validation Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Duplicate check using existing enrollments list
            bool alreadyEnrolled = enrollments.Any(e =>
                e.StudentId == studentId && e.CourseName == courseName);

            if (alreadyEnrolled)
            {
                MessageBox.Show("Student is already enrolled in this course.", "Duplicate Enrollment",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Create and store enrollment
            Enrollment enrollment = new Enrollment
            {
                StudentId = studentId,
                StudentName = studentName,
                CourseName = courseName,
                Semester = semester
            };
            enrollments.Add(enrollment);

            // Display success message
            txtEnrollmentOutput.Text =
                "Enrollment completed successfully!" + Environment.NewLine +
                "Student ID: " + enrollment.StudentId + Environment.NewLine +
                "Student Name: " + enrollment.StudentName + Environment.NewLine +
                "Course: " + enrollment.CourseName + Environment.NewLine +
                "Semester: " + enrollment.Semester;
        }

        private void btnClearEnrollment_Click(object sender, EventArgs e)
        {
            txtEnrollStudentId.Clear();
            txtEnrollStudentName.Clear();
            cmbCourse.SelectedIndex = -1;
            cmbSemester.SelectedIndex = -1;
            txtEnrollmentOutput.Clear();
            txtEnrollStudentId.Focus();
        }

        private void btnBackEnrollment_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
